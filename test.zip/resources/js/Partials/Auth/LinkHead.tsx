export default function LinkHead() {
    return <link href="/dist/css/tabler.min.css?1684106062" rel="stylesheet" />;
}
