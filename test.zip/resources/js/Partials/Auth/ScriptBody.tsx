import React from "react";

export default function ScriptBody() {
    return (
        <>
            <script src="/dist/js/tabler.min.js?1684106062" defer></script>
            <script src="/dist/js/demo.min.js?1684106062" defer></script>
        </>
    );
}
